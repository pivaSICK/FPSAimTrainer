# Links for download



* [MEGA](https://mega.nz/folder/D6gTCJZZ#QflODeYPeTFQ5KTl4yv1JA/folder/Oz4nEAQL)
* [Google Drive](https://drive.google.com/drive/folders/131AACe7GGHcpAA-t9A79Z9pdGzQzcv1C?hl=ru)
* [Yandex disk](https://disk.yandex.ru/d/Q_CURvHFUOXtIQ)
